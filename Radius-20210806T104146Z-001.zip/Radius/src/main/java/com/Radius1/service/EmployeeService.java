package com.Radius1.service;

import java.security.cert.PKIXRevocationChecker.Option;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.Radius1.Entity.Departmant;
import com.Radius1.Entity.Employee;
import com.Radius1.repository.DepartmentRepo;
import com.Radius1.repository.EmpRepo;
import com.google.common.base.Optional;

@Service
public class EmployeeService {
	
	@Autowired
	EmpRepo empRepo;
	@Autowired
	DepartmentRepo dpRepo;
	
public List<Employee> allData(){
	
	List lst =empRepo.findAll();
	return lst;
}

public Employee add(Employee emp) throws Exception{
	java.util.Optional<Employee> find = empRepo.findById(emp.getId());
	if(find.isPresent())
	{Employee emp1 = find.get();
		emp1.setName(emp.getName());
		emp1.setSalary(emp.getSalary());
		emp1.setAge(emp.getAge());
		emp1=empRepo.save(emp1);
		return emp1;		
	}else {		return emp;}}

public List<Departmant> alldpData(){
	List lst =dpRepo.findAll();
	return lst;}
public Departmant add1(Departmant dp) throws Exception
{
 java.util.Optional<Departmant> find1 = dpRepo.findById(dp.getCode());
 if(find1.isPresent())
 { Departmant dp1 = find1.get();
	 dp1.setDepartment(dp.getDepartment());
	 dp1= dpRepo.save(dp1);
	 return dp1;
 }
 else {
	 return dp;
 }
}


}
