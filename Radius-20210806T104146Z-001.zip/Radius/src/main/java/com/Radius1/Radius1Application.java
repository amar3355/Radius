package com.Radius1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Radius1Application {

	public static void main(String[] args) {
		SpringApplication.run(Radius1Application.class, args);
	}

}
