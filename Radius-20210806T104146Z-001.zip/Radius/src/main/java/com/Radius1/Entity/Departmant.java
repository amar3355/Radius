package com.Radius1.Entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Departmant {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private long code;
	private String department ;
    
	public Departmant() {
		super();
	}
	public long getCode() {
		return code;
	}
	public void setCode(long code) {
		this.code = code;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	
	public Departmant(long code, String department) {
		super();
		this.code = code;
		this.department = department;
		
	}
	@Override
	public String toString() {
		return "Departmant [code=" + code + ", department=" + department + "]";
	}
	

}
